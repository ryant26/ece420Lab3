#ifndef MAIN_H
#define MAIN_H

int find_max_indice(int, double**, int);
void swap_rows(double**, int, int);
void get_result(double *, double **, int);

#endif
